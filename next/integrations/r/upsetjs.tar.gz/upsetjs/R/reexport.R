#
# @upsetjs/r
# https://github.com/upsetjs/upsetjs_r
#
# Copyright (c) 2021 Samuel Gratzl <sam@sgratzl.com>
#


#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
