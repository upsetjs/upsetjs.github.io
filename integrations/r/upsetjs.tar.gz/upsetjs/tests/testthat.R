library(testthat)
library(upsetjs)

test_check("upsetjs")
